﻿using Entidades;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AccesoDatos
{
    public class RepositorioTXT
    {

        string filename_pacientes;
        string filename_resultados;

        public RepositorioTXT()
        {
            filename_pacientes = "Pacientes.txt";
            filename_resultados = "Resultados.txt";
        }

        public void Grabar_Pacientes(List<Paciente> _listapacientes)
        {
            try
            {
                TextWriter tw = new StreamWriter(filename_pacientes);

                foreach (Paciente p in _listapacientes)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append(p.DNI); sb.Append(",");
                    sb.Append(p.nombre_completo); sb.Append(",");
                    sb.Append(p.edad.ToString()); sb.Append(",");
                    sb.Append(p.genero.ToString()); sb.Append(",");
                    sb.Append(p.nro_celular); sb.Append(",");
                    sb.Append(p.Distrito); sb.Append(",");
                    sb.Append(p.direccion);

                    tw.WriteLine(sb);
                }


                tw.Flush();
                tw.Close();
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }


        public List<Paciente> Leer_Pacientes()
        {
            List<Paciente> aux = new List<Paciente>();

            List<string> contenido_archivo = new List<string>();

            contenido_archivo = File.ReadAllLines(filename_pacientes).ToList();

            //1,1,1,M,1,ANCÓN,1
            //2,2,2,F,2,ATE,2
            foreach (String s in contenido_archivo)
            {
                char[] separador = { ',' };
                string[] arreglo = s.Split(separador);
                Paciente antiguo = new Paciente();
                antiguo.DNI = arreglo[0];
                antiguo.nombre_completo= arreglo[1];
                antiguo.edad= Convert.ToInt32(arreglo[2]);
                antiguo.genero = Convert.ToChar(arreglo[3]);
                antiguo.nro_celular = arreglo[4];
                antiguo.Distrito = arreglo[5];
                antiguo.direccion = arreglo[6];
                aux.Add(antiguo);
            }


            return aux;
        }


    }
}
