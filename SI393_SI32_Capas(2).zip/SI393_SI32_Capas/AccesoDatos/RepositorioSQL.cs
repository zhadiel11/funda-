﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;

namespace AccesoDatos
{
    public class RepositorioSQL
    {
        private string cadena_conexion;
        private string Table_name;
        private string comando_leer_todos;
        private string comando_insertar;
        private string comando_actualizar;
        private string comando_borrar;

        public RepositorioSQL()
        {
              cadena_conexion="Data Source=. ; Initial Catalog=SI32; Integrated Security=true";
              Table_name="dbo.Resultado";
              comando_leer_todos = " SELECT [DNI] ,[tipo_prueba] ,[fecha_prueba] ,[fecha_resultado]  ,[infectado]  FROM [dbo].[Resultado]";
              comando_insertar = " INSERT INTO [dbo].[Resultado]   ([DNI],[tipo_prueba],[fecha_prueba] ,[fecha_resultado],[infectado])  VALUES (@DNI , @tipo_prueba "+
                                 " , @fecha_prueba , @fecha_resultado , @infectado)";

              comando_actualizar = " UPDATE [dbo].[Resultado]  SET[tipo_prueba] = @tipo_prueba ,[fecha_resultado] = @fecha_resultado ,[infectado] = @infectado " +
                                 " WHERE[DNI] = @DNI AND[fecha_prueba] = @fecha_prueba ";
              comando_borrar = " DELETE [dbo].[Resultado]  WHERE[DNI] = @DNI AND[fecha_prueba] = @fecha_prueba ";

        }

        public  List<Resultado> Leer_Resultados_deSQL()
        {
            List<Resultado> aux = new List<Resultado>();
            List<Paciente> aux_paciente = new RepositorioTXT().Leer_Pacientes();
            SqlConnection sqlcon = new SqlConnection(cadena_conexion);  // Variable para conectarme al SQL SERVER
            SqlCommand sqlcmd = new SqlCommand(comando_leer_todos, sqlcon);
            try
            {   sqlcon.Open();
                SqlDataReader dr = sqlcmd.ExecuteReader();
                while (dr.Read())
                {   Resultado nuevo = new Resultado();
                    nuevo.paciente = aux_paciente.Find(p => p.DNI.Equals(Convert.ToString(dr[0]).TrimEnd()));
                    nuevo.tipo_prueba = Convert.ToChar(dr[1]);
                    nuevo.fecha_prueba = Convert.ToString(dr[2]);
                    nuevo.fecha_resultado = Convert.ToString(dr[3]);
                    nuevo.infectado = Convert.ToBoolean(dr[4]);
                    nuevo.estado = Estados.antiguo;
                    aux.Add(nuevo);
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                sqlcon.Close();
            }
            return aux;
        }
        public void Insertar_Resultados_enSQL(List<Resultado> _lista_resultado)
        {
            SqlConnection sqlcon = new SqlConnection(cadena_conexion);  // Variable para conectarme al SQL SERVER
            SqlCommand sqlcmd = new SqlCommand(comando_insertar, sqlcon);
            try
            {   sqlcon.Open();
                foreach(Resultado r in _lista_resultado.FindAll(res=>res.estado==Estados.nuevo))
                {   sqlcmd.Parameters.Clear();
                    sqlcmd.Parameters.Add(new SqlParameter("@DNI",r.paciente.DNI));
                    sqlcmd.Parameters.Add(new SqlParameter("@tipo_prueba",r.tipo_prueba));
                    sqlcmd.Parameters.Add(new SqlParameter("@fecha_prueba",r.fecha_prueba));
                    sqlcmd.Parameters.Add(new SqlParameter("@fecha_resultado",r.fecha_resultado));
                    sqlcmd.Parameters.Add(new SqlParameter("@infectado",r.infectado));
                    sqlcmd.CommandType = System.Data.CommandType.Text;
                    sqlcmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                sqlcon.Close();
            }
        }
        public void Actualizar_Resultados_enSQL(List<Resultado> _lista_resultado)
        {
            SqlConnection sqlcon = new SqlConnection(cadena_conexion);  // Variable para conectarme al SQL SERVER
            SqlCommand sqlcmd = new SqlCommand(comando_actualizar, sqlcon);
            try
            {
                sqlcon.Open();
                foreach (Resultado r in _lista_resultado.FindAll(res => res.estado == Estados.actualizado))
                {
                    sqlcmd.Parameters.Clear();
                    sqlcmd.Parameters.Add(new SqlParameter("@DNI", r.paciente.DNI));
                    sqlcmd.Parameters.Add(new SqlParameter("@tipo_prueba", r.tipo_prueba));
                    sqlcmd.Parameters.Add(new SqlParameter("@fecha_prueba", r.fecha_prueba));
                    sqlcmd.Parameters.Add(new SqlParameter("@fecha_resultado", r.fecha_resultado));
                    sqlcmd.Parameters.Add(new SqlParameter("@infectado", r.infectado));
                    sqlcmd.CommandType = System.Data.CommandType.Text;
                    sqlcmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                sqlcon.Close();
            }
        }

        public void Eliminar_Resultados_enSQL(List<Resultado> _lista_resultado)
        {
            SqlConnection sqlcon = new SqlConnection(cadena_conexion);  // Variable para conectarme al SQL SERVER
            SqlCommand sqlcmd = new SqlCommand(comando_borrar, sqlcon);
            try
            {
                sqlcon.Open();
                foreach (Resultado r in _lista_resultado.FindAll(res => res.estado == Estados.eliminado))
                {
                    sqlcmd.Parameters.Clear();
                    sqlcmd.Parameters.Add(new SqlParameter("@DNI", r.paciente.DNI));
                    sqlcmd.Parameters.Add(new SqlParameter("@fecha_prueba", r.fecha_prueba));
                    sqlcmd.CommandType = System.Data.CommandType.Text;
                    sqlcmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            { throw ex; }
            finally
            {
                sqlcon.Close();
            }
        }
    }
}
