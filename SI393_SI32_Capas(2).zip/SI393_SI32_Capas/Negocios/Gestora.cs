﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Negocios
{
    public class Gestora
    {

        public List<Paciente> _listapacientes;
        public List<Resultado> _listaresultados;


        public Gestora()
        {
            _listapacientes = new List<Paciente>();
            _listaresultados = new List<Resultado>();

        }

        public bool Valida_Existe_Paciente_con_DNI( string Dni_buscar)
        {
            return _listapacientes.Exists(p => p.DNI.Equals(Dni_buscar));
        }

        public bool Insertar_Paciente(Paciente nuevo)
        {
            bool resultado;
            if (!Valida_Existe_Paciente_con_DNI(nuevo.DNI))
            {
                _listapacientes.Add(nuevo);
                resultado = true;
            }
            else
                resultado = false;

            return resultado;

        }

        public void Grabar_Pacientes_en_RepositorioTXT()
        {
            try
            {
                AccesoDatos.RepositorioTXT repo = new AccesoDatos.RepositorioTXT();

                repo.Grabar_Pacientes(_listapacientes);
            }
            catch (Exception ex)
            { throw ex; }


        }

        public void Load_Pacientes_del_RepositorioTXT()
        {
            try
            {
                AccesoDatos.RepositorioTXT repo = new AccesoDatos.RepositorioTXT();

                _listapacientes=repo.Leer_Pacientes();
            }
            catch (Exception ex)
            { throw ex; }

        }

        public void Load_Resultados_del_RepositorioSQL()
        {
            try
            {
                AccesoDatos.RepositorioSQL repo = new AccesoDatos.RepositorioSQL();

                _listaresultados = repo.Leer_Resultados_deSQL();
            }
            catch (Exception ex)
            { throw ex; }

        }
        public void Mantenimiento_Resultados_al_RepositorioSQL()
        {
            try
            {
                AccesoDatos.RepositorioSQL repo = new AccesoDatos.RepositorioSQL();
                repo.Insertar_Resultados_enSQL(_listaresultados);
                repo.Actualizar_Resultados_enSQL(_listaresultados);
                repo.Eliminar_Resultados_enSQL(_listaresultados);
                repo.Leer_Resultados_deSQL();
            }
            catch (Exception ex)
            { throw ex; }
        }

        public void Mantenimiento_enLista_Resultado(Resultado nuevo)
        {
            if (nuevo.estado==Estados.nuevo)
            _listaresultados.Add(nuevo);
            if (nuevo.estado == Estados.actualizado)
                _listaresultados.Find(r => r.paciente.DNI.Equals(nuevo.paciente.DNI) && r.fecha_prueba.Equals(nuevo.fecha_prueba)).estado = Estados.actualizado;
            if (nuevo.estado == Estados.eliminado)
                _listaresultados.Find(r => r.paciente.DNI.Equals(nuevo.paciente.DNI) && r.fecha_prueba.Equals(nuevo.fecha_prueba)).estado = Estados.eliminado;

        }



    }
}
