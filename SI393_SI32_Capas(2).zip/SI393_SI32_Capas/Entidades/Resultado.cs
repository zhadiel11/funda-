﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

    public class Resultado : EntidadesBase
    {
        public Paciente paciente { get; set; }
        public char tipo_prueba { get; set; }
        public string fecha_prueba { get; set; }
        public string fecha_resultado { get; set; }
        public bool infectado { get; set; }


    }
}
