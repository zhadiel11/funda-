﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Paciente
    {

       public string  DNI { get; set; }
       public string nombre_completo { get; set; }
       public int edad { get; set; }
       public char genero { get; set; }
       public string nro_celular { get; set; }
       public string Distrito { get; set; }
       public string direccion { get; set; }


        public override string ToString()
        {
            return DNI;
        }

    }
}
