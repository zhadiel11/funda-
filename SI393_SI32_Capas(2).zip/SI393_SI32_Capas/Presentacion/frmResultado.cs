﻿using Entidades;
using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoenCapas
{
    public partial class frmResultado : Form
    {
        public Gestora objgestora { get; set; }
        public Resultado objeto_seleccionado;
        public frmResultado()
        {
            InitializeComponent();
        }

        public void Show_Datos_Pacientes()
        {
            cbxPaciente.DataSource = null;
            cbxPaciente.DataSource = objgestora._listapacientes;
            cbxPaciente.DisplayMember = "nombre_completo";
            cbxPaciente.ValueMember = "DNI";
        }

        private bool Verifica_Datos_OK()
        {
          
            return (cbxPaciente.SelectedIndex != -1)  && ( dtpkFechaPrueba.Value.Ticks < dtpkFechaResultado.Value.Ticks);

        }


        private void button1_Click(object sender, EventArgs e)
        {
            if (Verifica_Datos_OK())
            {
                Resultado nuevo = new Resultado();
                nuevo.paciente = objgestora._listapacientes.Find(p => p.DNI.Equals(cbxPaciente.SelectedValue.ToString()));
                nuevo.tipo_prueba = rdbtnM.Checked ? 'M' : 'R';
                nuevo.fecha_prueba = dtpkFechaPrueba.Value.ToString("dd/MM/yyyy");
                nuevo.fecha_resultado = dtpkFechaResultado.Value.ToString("dd/MM/yyyy");
                nuevo.infectado = chkbxInfectado.Checked;
                nuevo.estado = Estados.nuevo;
                objgestora.Mantenimiento_enLista_Resultado(nuevo);
                objgestora.Mantenimiento_Resultados_al_RepositorioSQL();
                button2_Click(sender,e);
            }
            else
                MessageBox.Show("Debe de ingresar todos los datos");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dtgrDatos.DataSource = null;
            dtgrDatos.DataSource = objgestora._listaresultados.FindAll(r=>r.estado!=Estados.eliminado);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                objgestora.Mantenimiento_Resultados_al_RepositorioSQL();
                MessageBox.Show("EXITO");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR");
            }

        }

        private void dtgrDatos_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                objeto_seleccionado = objgestora._listaresultados[e.RowIndex];

                if (objeto_seleccionado.tipo_prueba == 'R') rdbtnR.Checked = true;
                if (objeto_seleccionado.tipo_prueba == 'M') rdbtnM.Checked = true;
            }
            else
                objeto_seleccionado = null;

        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (objeto_seleccionado != null)
                objeto_seleccionado.estado = Estados.eliminado;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (objeto_seleccionado != null)
            {
                objeto_seleccionado.estado = Estados.actualizado;
                objeto_seleccionado.tipo_prueba = rdbtnM.Checked ? 'M' : 'R';
                objeto_seleccionado.fecha_resultado = dtpkFechaResultado.Value.ToString("dd/MM/yyyy");
                objeto_seleccionado.infectado = chkbxInfectado.Checked;
            }
        }
    }
}
