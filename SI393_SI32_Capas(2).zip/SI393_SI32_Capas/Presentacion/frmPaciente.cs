﻿using Entidades;
using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoenCapas
{
    public partial class frmPaciente : Form
    {
        public Gestora objgestora { get; set; }

        public frmPaciente()
        {
            InitializeComponent();
        }

        private void btnGrabar_Click(object sender, EventArgs e)
        {
            try
            {
                objgestora.Grabar_Pacientes_en_RepositorioTXT();
                MessageBox.Show("EXITO");
            }
            catch (Exception ex)
            {
                MessageBox.Show("ERROR");
            }
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            //En la lista

            Paciente nuevo = new Paciente();
            nuevo.DNI = tbxDNI.Text;
            nuevo.nombre_completo = tbxNombreCompleto.Text;
            nuevo.nro_celular = tbxCelular.Text;
            nuevo.edad = Convert.ToInt32(tbxEdad.Text);
            nuevo.genero = rdbtnF.Checked ? 'F' : 'M';
            nuevo.Distrito = cbxDistrito.Items[cbxDistrito.SelectedIndex].ToString();
            nuevo.direccion = tbxDireccion.Text;

            if (objgestora.Insertar_Paciente(nuevo))

                MessageBox.Show("EXITO");
            else
                MessageBox.Show("ERROR");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            dataGridView1.DataSource = objgestora._listapacientes;



        }
    }
}
