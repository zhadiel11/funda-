﻿using Negocios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoenCapas
{
    public partial class FrmMenuPrincipal : Form
    {
        Gestora objgestora_principal;
        public FrmMenuPrincipal()
        {
            InitializeComponent();
            objgestora_principal = new Gestora();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmPaciente frm = new frmPaciente();
            objgestora_principal.Load_Pacientes_del_RepositorioTXT();
            frm.objgestora = objgestora_principal;
            frm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmResultado frm = new frmResultado();
            objgestora_principal.Load_Pacientes_del_RepositorioTXT();
            objgestora_principal.Load_Resultados_del_RepositorioSQL();
            frm.objgestora = objgestora_principal;
            frm.Show_Datos_Pacientes();
            frm.Show();
        }
    }
}
