﻿namespace ProyectoenCapas
{
    partial class frmPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbxDNI = new System.Windows.Forms.TextBox();
            this.tbxNombreCompleto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbxEdad = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.rdbtnM = new System.Windows.Forms.RadioButton();
            this.rdbtnF = new System.Windows.Forms.RadioButton();
            this.tbxCelular = new System.Windows.Forms.TextBox();
            this.Celular = new System.Windows.Forms.Label();
            this.cbxDistrito = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbxDireccion = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btnGrabar = new System.Windows.Forms.Button();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "DNI : ";
            // 
            // tbxDNI
            // 
            this.tbxDNI.Location = new System.Drawing.Point(87, 36);
            this.tbxDNI.MaxLength = 8;
            this.tbxDNI.Name = "tbxDNI";
            this.tbxDNI.Size = new System.Drawing.Size(172, 22);
            this.tbxDNI.TabIndex = 1;
            // 
            // tbxNombreCompleto
            // 
            this.tbxNombreCompleto.Location = new System.Drawing.Point(437, 38);
            this.tbxNombreCompleto.MaxLength = 150;
            this.tbxNombreCompleto.Name = "tbxNombreCompleto";
            this.tbxNombreCompleto.Size = new System.Drawing.Size(338, 22);
            this.tbxNombreCompleto.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(303, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(129, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nombre Completo :";
            // 
            // tbxEdad
            // 
            this.tbxEdad.Location = new System.Drawing.Point(87, 74);
            this.tbxEdad.Name = "tbxEdad";
            this.tbxEdad.Size = new System.Drawing.Size(100, 22);
            this.tbxEdad.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Edad : ";
            // 
            // rdbtnM
            // 
            this.rdbtnM.AutoSize = true;
            this.rdbtnM.Location = new System.Drawing.Point(301, 80);
            this.rdbtnM.Name = "rdbtnM";
            this.rdbtnM.Size = new System.Drawing.Size(92, 21);
            this.rdbtnM.TabIndex = 6;
            this.rdbtnM.TabStop = true;
            this.rdbtnM.Text = "Masculino";
            this.rdbtnM.UseVisualStyleBackColor = true;
            // 
            // rdbtnF
            // 
            this.rdbtnF.AutoSize = true;
            this.rdbtnF.Location = new System.Drawing.Point(437, 80);
            this.rdbtnF.Name = "rdbtnF";
            this.rdbtnF.Size = new System.Drawing.Size(91, 21);
            this.rdbtnF.TabIndex = 7;
            this.rdbtnF.TabStop = true;
            this.rdbtnF.Text = "Femenino";
            this.rdbtnF.UseVisualStyleBackColor = true;
            // 
            // tbxCelular
            // 
            this.tbxCelular.Location = new System.Drawing.Point(675, 74);
            this.tbxCelular.Name = "tbxCelular";
            this.tbxCelular.Size = new System.Drawing.Size(100, 22);
            this.tbxCelular.TabIndex = 9;
            // 
            // Celular
            // 
            this.Celular.AutoSize = true;
            this.Celular.Location = new System.Drawing.Point(613, 80);
            this.Celular.Name = "Celular";
            this.Celular.Size = new System.Drawing.Size(64, 17);
            this.Celular.TabIndex = 8;
            this.Celular.Text = "Celular : ";
            // 
            // cbxDistrito
            // 
            this.cbxDistrito.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxDistrito.FormattingEnabled = true;
            this.cbxDistrito.Items.AddRange(new object[] {
            "ANCÓN",
            "ATE",
            "BARRANCO",
            "BREÑA",
            "CARABAYLLO",
            "CHACLACAYO",
            "CHORRILLOS",
            "CIENEGUILLA",
            "COMAS",
            "EL AGUSTINO",
            "INDEPENDENCIA",
            "JESÚS MARÍA",
            "LA MOLINA",
            "LA VICTORIA",
            "LIMA",
            "LINCE",
            "LOS OLIVOS",
            "LURIGANCHO-CHOSICA",
            "LURÍN",
            "MAGDALENA DEL MAR",
            "MIRAFLORES",
            "PACHACÁMAC",
            "PUCUSANA",
            "PUEBLO LIBRE",
            "PUENTE PIEDRA",
            "PUNTA HERMOSA",
            "PUNTA NEGRA",
            "RÍMAC",
            "SAN BARTOLO",
            "SAN BORJA",
            "SAN ISIDRO",
            "SAN JUAN DE LURIGANCHO",
            "SAN JUAN DE MIRAFLORES",
            "SAN LUIS",
            "SAN MARTIN DE PORRES",
            "SAN MIGUEL",
            "SANTA ANITA",
            "SANTA MARÍA DEL MAR",
            "SANTA ROSA",
            "SANTIAGO DE SURCO",
            "SURQUILLO",
            "VILLA EL SALVADOR",
            "VILLA MARIA DEL TRIUNFO"});
            this.cbxDistrito.Location = new System.Drawing.Point(87, 128);
            this.cbxDistrito.Name = "cbxDistrito";
            this.cbxDistrito.Size = new System.Drawing.Size(169, 24);
            this.cbxDistrito.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 11;
            this.label5.Text = "Distrito";
            // 
            // tbxDireccion
            // 
            this.tbxDireccion.Location = new System.Drawing.Point(369, 130);
            this.tbxDireccion.Name = "tbxDireccion";
            this.tbxDireccion.Size = new System.Drawing.Size(406, 22);
            this.tbxDireccion.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(294, 135);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 17);
            this.label6.TabIndex = 12;
            this.label6.Text = "Dirección";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.btnInsertar);
            this.groupBox1.Controls.Add(this.btnGrabar);
            this.groupBox1.Controls.Add(this.tbxDNI);
            this.groupBox1.Controls.Add(this.tbxDireccion);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.tbxNombreCompleto);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.cbxDistrito);
            this.groupBox1.Controls.Add(this.tbxCelular);
            this.groupBox1.Controls.Add(this.tbxEdad);
            this.groupBox1.Controls.Add(this.Celular);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.rdbtnF);
            this.groupBox1.Controls.Add(this.rdbtnM);
            this.groupBox1.Location = new System.Drawing.Point(35, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(798, 228);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del Paciente";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(35, 267);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(798, 302);
            this.dataGridView1.TabIndex = 15;
            // 
            // btnGrabar
            // 
            this.btnGrabar.Location = new System.Drawing.Point(588, 183);
            this.btnGrabar.Name = "btnGrabar";
            this.btnGrabar.Size = new System.Drawing.Size(187, 31);
            this.btnGrabar.TabIndex = 14;
            this.btnGrabar.Text = "Grabar en Repositorio";
            this.btnGrabar.UseVisualStyleBackColor = true;
            this.btnGrabar.Click += new System.EventHandler(this.btnGrabar_Click);
            // 
            // btnInsertar
            // 
            this.btnInsertar.Location = new System.Drawing.Point(124, 183);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(211, 31);
            this.btnInsertar.TabIndex = 15;
            this.btnInsertar.Text = "Insertar Nuevo en Lista";
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(382, 183);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 31);
            this.button1.TabIndex = 16;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmPaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(907, 608);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Name = "frmPaciente";
            this.Text = "frmPaciente";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbxDNI;
        private System.Windows.Forms.TextBox tbxNombreCompleto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbxEdad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RadioButton rdbtnM;
        private System.Windows.Forms.RadioButton rdbtnF;
        private System.Windows.Forms.TextBox tbxCelular;
        private System.Windows.Forms.Label Celular;
        private System.Windows.Forms.ComboBox cbxDistrito;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbxDireccion;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnGrabar;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.Button button1;
    }
}